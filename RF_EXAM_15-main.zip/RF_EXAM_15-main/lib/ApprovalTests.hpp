#ifndef APPROVAL_TEST_1_APPROVALTESTS_HPP
#define APPROVAL_TEST_1_APPROVALTESTS_HPP
#include "ApprovalTests.v.6.0.0.hpp"
#endif
