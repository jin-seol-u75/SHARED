#include "Performance.h"
#include "StatementPrinter.h"
#include <sstream>
#include <cmath>
#include <map>
#include <iostream>
#include <vector>

using namespace std;

std::string StatementPrinter::print(Invoice invoice, map<string, shared_ptr<Play>> plays) {
    
    std::vector<Performance>::iterator iter = invoice.performances_.begin();
    std::vector<Performance>::iterator iter_end = invoice.performances_.end();
    
    float totalAmount = 0;
    int volumeCredits = 0;
    std::ostringstream result;
    result << "Statement for " << invoice.customer_ << "\n";
    
    for (; iter!=iter_end; ++iter) {
        Performance perf = *iter;
        shared_ptr<Play> play = plays[perf.playID_];
        //std::cout << perf.playID_ << play->type_ << std::endl;
        
        float thisAmount = 0;
        
        if (play->type_ == "tragedy") {
            thisAmount = 40000;
            if (perf.audience_ > 30) {
                thisAmount += 1000 * (perf.audience_ - 30);
            }
        }
        else if (play->type_ == "comedy") {
            thisAmount = 30000;
            if (perf.audience_ > 20) {
                thisAmount += 10000 + 500 * (perf.audience_ - 20);
            }
            thisAmount += 300 * perf.audience_;
        }
        else {
            throw std::domain_error("unknown type: " + play->type_);            
        }

        // add volume credits
        volumeCredits += std::max(perf.audience_ - 30, 0);
        
        // add extra credit for every ten comedy attendees
        if (play->type_ == "comedy") 
            volumeCredits += floor(perf.audience_ / 5);

        // print line for this order
        result << "  " << play->name_ << ": $" << presentPrice(thisAmount/100) << 
            " (" << perf.audience_ << " seats)\n";
        
        totalAmount += thisAmount;
        
    }
    result << "Amount owed is $" << presentPrice(totalAmount / 100.0f) << "\n";
    result << "You earned " << volumeCredits << " credits\n";
    
    return result.str();

}

string StatementPrinter::presentPrice(double price)
{
    char buf[20];
    snprintf(buf, 20, "%.2f", price);
    return string(buf);
}
