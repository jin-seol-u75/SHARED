#ifndef PLAY_H
#define PLAY_H

#include <string>
using std::string;

class Play {
public:
    Play(string name, string type) 
        : name_(name), type_(type) {
    }
    
    string name_;
    string type_;   
};

#endif