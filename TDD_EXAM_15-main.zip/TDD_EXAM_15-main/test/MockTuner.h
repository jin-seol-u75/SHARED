#ifndef MOCKTUNER_H_
#define MOCKTUNER_H_

#include "gmock/gmock.h"
#include "../src/Tuner.h"
#include <iostream>

class MockTuner: public Tuner {
public:
    //virtual int getCH() = 0;
    MOCK_METHOD(int, getCH, (), (override));
	//virtual void setCH(std::string ch) = 0;
    MOCK_METHOD(void, setCH, (std::string), (override));
	//virtual std::string seekCH() = 0;
	MOCK_METHOD(std::string, seekCH, (), (override));
};

#endif
