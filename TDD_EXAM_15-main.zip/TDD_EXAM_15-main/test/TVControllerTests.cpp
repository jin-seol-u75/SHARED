// TVControllerTests.cpp : Defines the entry point for the console application.
//

#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "MockTuner.h"
#include "../src/TVController.h"

using namespace testing;

//To-Do : 한자리 숫자 누르고 OK 누를때
TEST(TVControllerTests, press1digitAndPressOK)
{
	MockTuner tuner;
    TVController tv(&tuner);
    
    EXPECT_CALL(tuner, setCH("1")) 
        .Times(1);        

    tv.pushButton(remoteKey::KEY_1);
    tv.pushButton(remoteKey::KEY_OK);
}

//To-Do : 두자리 숫자 누를때
TEST(TVControllerTests, press2digits)
{
	
}


//To-Do : 이전채널 누를때
TEST(TVControllerTests, pressPrevButton)
{
    MockTuner tuner;
    TVController tv(&tuner);
    //tv.setTunerCh("64");
    //tv.setTunerCh("12");
    //ASSERT_EQ("64", 현재채널);
    //ASSERT_EQ("12", 이전채널);
}


//To-Do : 선호채널 누를때 - 추가, 삭제
TEST(TVControllerTests, pressFavoriteButton)
{

}

//To-Do : 다음 선호 채널 누를때
TEST(TVControllerTests, pressNextFavoriteButton)
{

}

//To-Do : UP을 누를때
TEST(TVControllerTests, pressUpButtonWithoutSearchedChannelList)
{

}


//To-Do : DOWN을 누를때
TEST(TVControllerTests, pressDownButtonWithoutSearchedChannelList)
{

}

//To-Do : 채널 검색을 누를때
TEST(TVControllerTests, pressSearchChannelButton)
{

}


//To-Do : UP을 누를때
TEST(TVControllerTests, pressUpButtonWithSearchedChannelList)
{

}


//To-Do : DOWN을 누를때
TEST(TVControllerTests, pressDownButtonWithSearchedChannelList)
{

}

int main(int argc, char** argv)
{
	InitGoogleMock(&argc, argv);

	return RUN_ALL_TESTS();
}