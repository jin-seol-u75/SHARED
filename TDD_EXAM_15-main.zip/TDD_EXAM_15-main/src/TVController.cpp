#include "TVController.h"
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

TVController::TVController(Tuner* tuner)
{
	tuner_ = tuner;
	processingCH_ = "";
}

void TVController::pushButton(remoteKey key)
{
    switch (key) {
        case remoteKey::KEY_1:
            processingCH_ += to_string(static_cast<int>(key));
            break;

        case remoteKey::KEY_OK:
            setTunerCh();
            break;
    }
}

void TVController::setTunerCh()
{
    //cout<<"현재 설정하는 채널 : "<< processingCH_ << endl;
    tuner_->setCH(processingCH_);    
}
