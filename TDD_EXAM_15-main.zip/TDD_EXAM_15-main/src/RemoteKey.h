#ifndef REMOTEKEY_H_
#define REMOTEKEY_H_

enum class remoteKey{
    KEY_0 = 0,
    KEY_1 = 1,
    KEY_OK = 101
	//To-Do : 추가 키 정의
};

#endif

