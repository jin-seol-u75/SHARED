#ifndef TVCONTROLLER_H_
#define TVCONTROLLER_H_

#include "RemoteKey.h"
#include "Tuner.h"
using namespace std;

class TVController
{
public:
	TVController(Tuner* tuner);
	void pushButton(remoteKey key);
private:
	void setTunerCh();
	Tuner* tuner_;
	std::string processingCH_;    
};

#endif
